# Juniper Salon - cancellation waitlist

Local assessment prototype adapted from [the supplied starter](https://github.com/john-b-yang/temporal-waitlist-assessment-starter). Uses real Temporal Workflows, durable timers, Queries and Updates. No public deployment.

## Run locally

Requirements: Node.js 20+ and Docker Desktop running.

```sh
npm ci
npm run dev
```

Open http://localhost:3000. Temporal UI: http://localhost:8233.

```sh
npm run typecheck
npm test
npm run stop
```

Tests download the official Temporal time-skipping test server on first use; Docker is not needed for tests. The app binds to 127.0.0.1. Temporal's Docker volume persists Workflow history across server restarts. Stop with Ctrl+C; `npm run stop` stops the server without deleting the volume. Do not use `docker compose down -v` if you want to retain history.

If you already run a local Temporal server, launch `npm run dev:worker` and `npm run dev:api` in separate terminals. Set TEMPORAL_ADDRESS if it is not localhost:7233. This is a local demo without authentication; do not expose it to the Internet.

## Demo for Lena (about 5 minutes)

1. Open the app. Keep Haircut / Lena. Choose the 30-second offer window for the demo; the assumed business default is 15 minutes.
2. Approve outreach. Avery gets the first invitation. Jordan is skipped because the requested service does not match.
3. Let Avery's timer expire, or click No thanks. Sam gets the next offer.
4. Click Accept appointment. Sam is reserved, outreach ends, and the activity history records it. The salon calendar is not actually modified.
5. Refresh the browser. The saved opening reference resumes the same Temporal Workflow and shows the result.
6. Click New opening to create another reference. Previous outreach continues unless you close it; use its reference to resume it.
7. Recovery demonstration: start a new opening with a 5-minute window; stop only the Worker, keeping Temporal and the API running. Restart the Worker. Resume the same reference. The deadline and offer persist; an elapsed deadline advances to the next client. With `npm run dev`, Ctrl+C stops both child processes but keeps Temporal running; run `npm run dev` again to resume.

## Customer assumptions (no interview was provided)

- Only clients who asked for an earlier appointment and opted into outreach are listed.
- Earlier waitlist entries are offered first, provided service and stylist match. Any stylist is allowed.
- One active offer per opening; staff approve the opening and choose the response window.
- Offer windows default to 15 minutes and are capped at the appointment start time.
- Staff can withdraw an opening while outreach is active.
- Acceptance reserves the opening in the prototype; staff confirm it in the real calendar.
- Success would mean more filled cancellation gaps and fewer staff minutes spent managing replies. No improvement figures are claimed.

## Temporal design

`src/workflows.ts` is the source of truth. One Workflow per opening reference snapshots the ordered waitlist, selects matching clients, and waits on a durable `condition` timer. The browser polls a Query; it does not drive expiration. Client replies and staff cancellation use synchronous Workflow Update handlers, serialized within the Workflow. Offer IDs, deadline checks and phase checks reject stale or duplicate replies. Acceptance closes the opening before another reply can claim it. Stable Workflow IDs and REJECT_DUPLICATE prevent restarting the same reference, including after completion. Completed state is read from the Workflow result.

No external side effects are performed, so no Activities are needed for this prototype. Production SMS delivery and calendar writes belong in retryable Activities with provider idempotency keys; retries alone do not ensure an external booking happens exactly once.

## Simulated and excluded work

Fictional waitlist. SMS is a visible in-browser message, and reply buttons simulate the recipient. Calendar reservation is Workflow state only. No real texts are sent and no existing appointments are moved. Waitlist changes are local until an opening snapshots them; this is not a persistent client database. There are no availability windows, duration checks, authentication, verified client links, consent/opt-out management, delivery retries or cross-opening conflict protection. Run one opening at a time in the demo. History follows local Temporal retention, not a permanent audit database.

## Validation and next step

Automated Workflow scenarios cover filtering, decline, expiry, stale replies, cancellation, competing acceptance and Worker restart recovery. See `evidence/validation.md` for observed results and environment limits. Presentation: [five PDF slides](evidence/lena-presentation.pdf).

Validate priority and offer rules with Lena, then pilot one stylist with an SMS sandbox and calendar integration. Add secure recipient links, opt-out handling, delivery status, availability checks and idempotent conflict-safe booking before live client use.

[Temporal TypeScript documentation](https://docs.temporal.io/develop/typescript)
