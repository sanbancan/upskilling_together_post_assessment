127.0.0.1 bindings for local evaluation. Temporal history persists in the named Docker volume.
