# Validation evidence

Checked 2026-10-04.

- `npm run typecheck`: passed.
- `npm test`: two tests passed. Scenarios include service/stylist filtering, decline, automatic expiry to exhausted, stale reply rejection, cancellation, competing acceptance (one accepted), and Worker stop/restart with the same offer and deadline preserved.
- Browser + API + Worker + official Temporal time-skipping test server: approved Haircut/Lena opening; Avery declined; Sam received the next offer and accepted; page reload restored completed reservation and history. This exercises actual Temporal calls, not a JavaScript mock.
- Browser layout inspected at mobile and desktop viewport settings. Screenshot: `prototype.jpg`.
- Five-page PDF rendered with Poppler; each slide visually inspected for fit and readability.
- `npm install`: zero reported vulnerabilities.

Limitations: Docker Desktop is unavailable in the authoring environment, so the Docker Compose launch path and full development server restart were not executed here. The official standalone dev server failed under this Windows sandbox's resource detection; the working test-server preview is temporary and is not the evaluator launch path. Evaluation should use the supplied Docker setup. Worker restart was tested against the same live Temporal test server; server restart persistence relies on the starter's named volume.

No SMS delivery or salon calendar API was invoked. All names are fictional. No public application deployment was performed. Repository visibility was checked through GitHub's API: public, not a fork.
