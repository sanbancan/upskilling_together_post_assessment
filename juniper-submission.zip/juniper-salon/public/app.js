const $ = s => document.querySelector(s);
const clients = [
 {id:'1',name:'Avery Chen',service:'Haircut',stylist:'Lena'},
 {id:'2',name:'Jordan Ellis',service:'Color',stylist:'Maya'},
 {id:'3',name:'Sam Rivera',service:'Haircut',stylist:'Any stylist'},
 {id:'4',name:'Casey Morgan',service:'Haircut',stylist:'Lena'}
];
let id = localStorage.getItem('juniper-opening') || '';
let status, busy = false;
$('#opening-id').value = id || `opening-${crypto.randomUUID().slice(0,8)}`;
const future = new Date(Date.now()+86400000); future.setMinutes(future.getMinutes()-future.getTimezoneOffset());
$('#starts').value = future.toISOString().slice(0,16);
function waitlist(){
 $('#waitlist').replaceChildren();
 (status?.opening.clients || clients).forEach((c,i)=>{const li=document.createElement('li');const detail=document.createElement('div');const name=document.createElement('strong');name.textContent=c.name;const small=document.createElement('small');small.textContent=`${c.service} · ${c.stylist}`;detail.append(name,small);li.append(detail);const remove=document.createElement('button');remove.textContent='Remove';remove.className='remove';remove.disabled=Boolean(status);remove.onclick=()=>{clients.splice(i,1);waitlist()};li.append(remove);$('#waitlist').append(li)});
}
async function api(url,body){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);try{const r=await fetch(url,{signal:controller.signal,...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});const data=await r.json();if(!r.ok)throw Error(data.error||'Request failed');return data}finally{clearTimeout(timer)}}
function error(e){$('#error').hidden=false;$('#error').textContent=e.name==='AbortError'?'Request timed out. Resume this reference before starting another opening.':e.message;$('#connection').textContent='Connection needs attention'}
function render(){
 $('#service').value=status.opening.service;$('#stylist').value=status.opening.stylist;$('#window').value=String(status.opening.offerSeconds);
 const date=new Date(status.opening.startsAt);date.setMinutes(date.getMinutes()-date.getTimezoneOffset());$('#starts').value=date.toISOString().slice(0,16);
 $('#error').hidden=true;$('#connection').textContent='Connected to Temporal';
 const titles={offering:'An invitation is open.',booked:'The opening is reserved.',exhausted:'Staff follow-up needed.',cancelled:'Outreach is closed.'};$('#phase').textContent=titles[status.phase];
 $('#summary').textContent=status.phase==='booked'?`${status.bookedClient.name} accepted. Confirm the appointment in your calendar; this demo does not update it.`:status.phase==='offering'?`${status.opening.service} with ${status.opening.stylist} · ${new Date(status.opening.startsAt).toLocaleString()}`:status.phase==='exhausted'?'The list ended or the appointment time arrived. No client was booked.':'The offer was withdrawn. No further clients will be contacted.';
 $('#offer').hidden=!status.offer;$('#cancel').hidden=status.phase!=='offering';
 if(status.offer){$('#offer-name').textContent=`Hi ${status.offer.client.name.split(' ')[0]},`;$('#offer-text').textContent=`A ${status.opening.service.toLowerCase()} with ${status.opening.stylist} opened at Juniper Salon on ${new Date(status.opening.startsAt).toLocaleString()}. Would you like it?`;const remaining=Math.max(0,Math.ceil((status.offer.expiresAt-Date.now())/1000));$('#countdown').textContent=`Offer expires in ${Math.floor(remaining/60)}m ${remaining%60}s`;$('#accept').disabled=busy||!remaining;$('#decline').disabled=busy||!remaining;}
 $('#events').replaceChildren();status.events.slice().reverse().forEach(e=>{const li=document.createElement('li');const time=document.createElement('time');time.textContent=new Date(e.at).toLocaleTimeString();li.append(time,document.createTextNode(e.message));$('#events').append(li)});
 $('#start').disabled=true;$('#client-form').hidden=true;for(const field of ['service','stylist','starts','window'])$('#'+field).disabled=true;waitlist();
}
async function refresh(){if(!id||busy)return;try{const requestedId=id;const data=await api(`/api/openings/${encodeURIComponent(requestedId)}`);if(requestedId!==id)return;status=data;render()}catch(e){error(e)}}
$('#opening-form').onsubmit=async e=>{e.preventDefault();if(busy)return;busy=true;$('#start').disabled=true;try{const nextId=$('#opening-id').value;await api('/api/openings',{id:nextId,service:$('#service').value,stylist:$('#stylist').value,startsAt:new Date($('#starts').value).toISOString(),offerSeconds:Number($('#window').value),clients});id=nextId;localStorage.setItem('juniper-opening',id);$('#feedback').textContent='Outreach approved. Waiting for the first offer.'}catch(e){error(e);$('#start').disabled=false}finally{busy=false;await refresh()}};
$('#resume').onclick=()=>{id=$('#opening-id').value;localStorage.setItem('juniper-opening',id);refresh()};
$('#client-form').onsubmit=e=>{e.preventDefault();clients.push({id:crypto.randomUUID(),name:$('#client-name').value.trim(),service:$('#client-service').value,stylist:$('#client-stylist').value});$('#client-name').value='';waitlist()};
async function reply(answer){if(busy||!status?.offer)return;const offerId=status.offer.id;busy=true;render();try{const r=await api(`/api/openings/${encodeURIComponent(id)}/reply`,{offerId,answer});$('#feedback').textContent=r.message}catch(e){error(e)}finally{busy=false;await refresh()}}
$('#accept').onclick=()=>reply('accept');$('#decline').onclick=()=>reply('decline');
$('#cancel').onclick=async()=>{if(busy)return;busy=true;try{const r=await api(`/api/openings/${encodeURIComponent(id)}/cancel`,{});$('#feedback').textContent=r.cancelled?'Opening closed.':'The opening was already resolved.'}catch(e){error(e)}finally{busy=false;await refresh()}};
waitlist();if(id)refresh();setInterval(refresh,1000);

$('#new-opening').onclick=()=>{if(busy)return;id='';status=undefined;localStorage.removeItem('juniper-opening');$('#opening-id').value='opening-'+crypto.randomUUID().slice(0,8);$('#start').disabled=false;for(const field of ['service','stylist','starts','window'])$('#'+field).disabled=false;$('#client-form').hidden=false;$('#offer').hidden=true;$('#cancel').hidden=true;$('#phase').textContent='An opening worth filling.';$('#summary').textContent='Approve an opening to invite the first matching client.';$('#events').textContent='Outreach has not started.';$('#feedback').textContent='Previous outreach continues in Temporal unless closed. Resume its reference to return.';$('#error').hidden=true;waitlist()};
