# Run this from your own signed-in Windows terminal.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
& git -c http.sslBackend=openssl push -u origin main
if ($LASTEXITCODE -ne 0) { throw 'Push failed. Sign into GitHub through Git Credential Manager, then run this script again.' }
Write-Host 'Submission pushed to https://github.com/sanbancan/upskilling_together_post_assessment'
