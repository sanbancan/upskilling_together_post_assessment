import path from 'node:path';
import { Client, Connection, WorkflowNotFoundError } from '@temporalio/client';
import express, { type NextFunction, type Request, type Response } from 'express';
import type { Opening, SalonStatus } from './types';
import { salonWorkflow } from './workflows';
const app = express();
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(process.cwd(), 'public')));
let clientPromise: Promise<Client> | undefined;
function getClient(): Promise<Client> {
  clientPromise ??= Connection.connect({ address: process.env.TEMPORAL_ADDRESS ?? 'localhost:7233' })
    .then(connection => new Client({ connection, namespace: 'default' }))
    .catch(error => { clientPromise = undefined; throw error; });
  return clientPromise;
}
app.post('/api/openings', async (request, response) => {
  const b = request.body;
  if (!b || typeof b.id !== 'string' || !/^[a-zA-Z0-9-]{1,80}$/.test(b.id) ||
      !['Haircut', 'Color'].includes(b.service) || !['Lena', 'Maya'].includes(b.stylist) ||
      !Number.isInteger(b.offerSeconds) || b.offerSeconds < 5 || b.offerSeconds > 3600 ||
      typeof b.startsAt !== 'string' || !Number.isFinite(Date.parse(b.startsAt)) || Date.parse(b.startsAt) <= Date.now() ||
      !Array.isArray(b.clients) || b.clients.length < 1 || b.clients.length > 50 ||
      b.clients.some((c: any) => !c || typeof c.id !== 'string' || typeof c.name !== 'string' || !c.name.trim() || c.name.length > 80 || !['Haircut', 'Color'].includes(c.service) || !['Lena', 'Maya', 'Any stylist'].includes(c.stylist))) {
    response.status(400).json({ error: 'Provide a future opening, valid service/stylist, 5-3600 second offer window, and 1-50 clients.' }); return;
  }
  const opening: Opening = b;
  const client = await getClient();
  try {
    await client.workflow.start(salonWorkflow, { workflowId: `juniper-${opening.id}`, taskQueue: 'assessment-starter', args: [opening], workflowIdReusePolicy: 'REJECT_DUPLICATE' });
  } catch (error) {
    if (error instanceof Error && error.name === 'WorkflowExecutionAlreadyStartedError') {
      response.status(409).json({ error: 'This opening already exists. Resume it instead.' }); return;
    }
    throw error;
  }
  response.status(201).json({ id: opening.id });
});
app.get('/api/openings/:id', async (request, response) => {
  const client = await getClient();
  const handle = client.workflow.getHandle(`juniper-${request.params.id}`);
  const description = await handle.describe();
  const status = description.status.name === 'COMPLETED' ? await handle.result() : await handle.query<SalonStatus>('getSalonStatus');
  response.json(status);
});
app.post('/api/openings/:id/reply', async (request, response) => {
  if (!['accept', 'decline'].includes(request.body?.answer) || typeof request.body?.offerId !== 'string') {
    response.status(400).json({ error: 'A valid offer ID and reply are required.' }); return;
  }
  const client = await getClient();
  const handle = client.workflow.getHandle(`juniper-${request.params.id}`);
  if ((await handle.describe()).status.name !== 'RUNNING') { response.status(409).json({ error: 'Outreach is already closed.' }); return; }
  response.json(await handle.executeUpdate('respondToOffer', { args: [request.body.offerId, request.body.answer] }));
});
app.post('/api/openings/:id/cancel', async (request, response) => {
  const client = await getClient();
  const handle = client.workflow.getHandle(`juniper-${request.params.id}`);
  if ((await handle.describe()).status.name !== 'RUNNING') { response.status(409).json({ error: 'Outreach is already closed.' }); return; }
  response.json({ cancelled: await handle.executeUpdate('cancelOpening') });
});
app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
  console.error(error);
  response.status(error instanceof WorkflowNotFoundError ? 404 : 503).json({ error: error instanceof WorkflowNotFoundError ? 'Opening not found.' : 'Unable to reach the workflow. Check Temporal and the Worker, then retry.' });
});
const port = Number(process.env.PORT ?? 3000);
app.listen(port, '127.0.0.1', () => console.log(`Juniper Salon: http://localhost:${port}`));
