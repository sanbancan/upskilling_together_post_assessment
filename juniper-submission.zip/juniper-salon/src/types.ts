export type ClientEntry = { id: string; name: string; service: string; stylist: string };
export type Opening = { id: string; service: string; stylist: string; startsAt: string; offerSeconds: number; clients: ClientEntry[] };
export type Offer = { id: string; client: ClientEntry; expiresAt: number };
export type SalonStatus = { opening: Opening; phase: 'offering' | 'booked' | 'exhausted' | 'cancelled'; offer?: Offer; bookedClient?: ClientEntry; events: { at: number; message: string }[] };
