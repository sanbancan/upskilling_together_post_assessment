import { condition, defineQuery, defineUpdate, setHandler } from '@temporalio/workflow';
import type { Opening, SalonStatus } from './types';
export const getSalonStatus = defineQuery<SalonStatus>('getSalonStatus');
export const respondToOffer = defineUpdate<{ accepted: boolean; message: string }, [string, 'accept' | 'decline']>('respondToOffer');
export const cancelOpening = defineUpdate<boolean>('cancelOpening');
export async function salonWorkflow(opening: Opening): Promise<SalonStatus> {
  const status: SalonStatus = { opening, phase: 'offering', events: [] };
  let reply: 'accept' | 'decline' | undefined;
  const log = (message: string) => status.events.push({ at: Date.now(), message });
  setHandler(getSalonStatus, () => status);
  setHandler(cancelOpening, () => {
    if (status.phase !== 'offering') return false;
    status.phase = 'cancelled'; log('Staff closed this opening. Pending offer withdrawn.'); return true;
  });
  // Temporal serializes replies and cancellation. Offer IDs and deadlines reject stale replies.
  setHandler(respondToOffer, (offerId, answer) => {
    if (status.phase !== 'offering' || !status.offer || status.offer.id !== offerId || reply || Date.now() >= status.offer.expiresAt) {
      return { accepted: false, message: 'This offer is no longer available. No booking was made.' };
    }
    reply = answer;
    log(`${status.offer.client.name} ${answer === 'accept' ? 'accepted' : 'declined'} the offer.`);
    if (answer === 'accept') { status.bookedClient = status.offer.client; status.phase = 'booked'; }
    return { accepted: true, message: answer === 'accept' ? 'Appointment reserved. Staff can confirm it in the salon calendar.' : 'Declined. Moving to the next matching client.' };
  });
  log('Staff approved outreach. Matching clients keep their waitlist order.');
  const clients = opening.clients.filter(c => c.service === opening.service && (c.stylist === opening.stylist || c.stylist === 'Any stylist'));
  for (let index = 0; index < clients.length; index++) {
    if (status.phase !== 'offering' || Date.now() >= Date.parse(opening.startsAt)) break;
    reply = undefined;
    const expiresAt = Math.min(Date.now() + opening.offerSeconds * 1000, Date.parse(opening.startsAt));
    status.offer = { id: `${opening.id}:${index}`, client: clients[index], expiresAt };
    log(`Offer opened for ${clients[index].name}. Message is simulated; no SMS sent.`);
    await condition(() => reply !== undefined || status.phase !== 'offering', Math.max(1, expiresAt - Date.now()));
    if (status.phase !== 'offering') break;
    if (!reply) log(`${clients[index].name}'s offer expired. Moving on automatically.`);
  }
  status.offer = undefined;
  if (status.phase === 'offering') { status.phase = 'exhausted'; log('No booking made. Staff follow-up needed; outreach ended.'); }
  if (status.phase === 'booked') log('One client reserved the opening. Calendar update is simulated.');
  return status;
}
