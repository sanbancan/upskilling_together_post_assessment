import assert from 'node:assert/strict';
import { test } from 'node:test';
import { TestWorkflowEnvironment } from '@temporalio/testing';
import { Worker } from '@temporalio/worker';
import { salonWorkflow } from '../src/workflows';
import type { Opening, SalonStatus } from '../src/types';
const clients = [{ id: '1', name: 'Avery', service: 'Haircut', stylist: 'Lena' }, { id: '2', name: 'Wrong match', service: 'Color', stylist: 'Lena' }, { id: '3', name: 'Sam', service: 'Haircut', stylist: 'Any stylist' }];
test('durable offers: matching, decline, stale reply, one booking, expiry and cancellation', async () => {
 const env = await TestWorkflowEnvironment.createTimeSkipping();
 try {
  const worker = await Worker.create({connection:env.nativeConnection,taskQueue:'salon-test',workflowsPath:require.resolve('../src/workflows')});
  await worker.runUntil(async()=>{
   const opening = (id:string):Opening=>({id,service:'Haircut',stylist:'Lena',startsAt:new Date(Date.now()+86400000).toISOString(),offerSeconds:30,clients});
   const start = (id:string)=>env.client.workflow.start(salonWorkflow,{workflowId:id,taskQueue:'salon-test',args:[opening(id)]});
   const h=await start('replies');
   assert.equal((await h.query<SalonStatus>('getSalonStatus')).offer?.client.name,'Avery');
   await h.executeUpdate('respondToOffer',{args:['replies:0','decline']});
   assert.equal((await h.query<SalonStatus>('getSalonStatus')).offer?.client.name,'Sam');
   const stale = await h.executeUpdate<{accepted:boolean}, [string, string]>('respondToOffer',{args:['replies:0','accept']});assert.equal(stale.accepted,false);
   await h.executeUpdate('respondToOffer',{args:['replies:1','accept']});
   const booked=await h.result();assert.equal(booked.phase,'booked');assert.equal(booked.bookedClient?.name,'Sam');assert.equal(booked.offer,undefined);
   const expired=await start('expiry');assert.equal((await expired.result()).phase,'exhausted');
   const cancelled=await start('cancel');await cancelled.executeUpdate('cancelOpening');assert.equal((await cancelled.result()).phase,'cancelled');
   const race=await start('race');const results=await Promise.all([race.executeUpdate<{accepted:boolean}, [string, string]>('respondToOffer',{args:['race:0','accept']}),race.executeUpdate<{accepted:boolean}, [string, string]>('respondToOffer',{args:['race:0','accept']}).catch(()=>({accepted:false}))]);assert.equal(results.filter(r=>r.accepted).length,1);assert.equal((await race.result()).phase,'booked');
  });
 }finally{await env.teardown()}
});


test('an offer and its deadline survive a Worker restart', async()=>{
 const env=await TestWorkflowEnvironment.createTimeSkipping();
 try{
  const options={connection:env.nativeConnection,taskQueue:'recovery',maxCachedWorkflows:0,workflowsPath:require.resolve('../src/workflows')};
  const opening:Opening={id:'recovery',service:'Haircut',stylist:'Lena',startsAt:new Date(Date.now()+86400000).toISOString(),offerSeconds:300,clients};
  const handle=await env.client.workflow.start(salonWorkflow,{workflowId:'recovery',taskQueue:'recovery',args:[opening]});
  let before:SalonStatus;
  const first=await Worker.create(options);
  await first.runUntil(async()=>{before=await handle.query<SalonStatus>('getSalonStatus');assert.equal(before.offer?.client.name,'Avery')});
  const second=await Worker.create(options);
  await second.runUntil(async()=>{const after=await handle.query<SalonStatus>('getSalonStatus');assert.deepEqual(after.offer,before.offer);await handle.executeUpdate('respondToOffer',{args:[after.offer!.id,'accept']});assert.equal((await handle.result()).phase,'booked')});
 }finally{await env.teardown()}
});

